/*
  HIH8121.h - Library for reading relative humidity and temperature data 
  This file was derived from the by David H Hagan library
  
  Use as you like. MIT license.
*/

#ifndef HIH8121_h
#define HIH8121_h

#include <Arduino.h>

class HIH8121 {

private:
    uint8_t _address;
    uint8_t _humidity_lo, _humidity_hi;
    uint8_t _temp_lo, _temp_hi;
    uint8_t _status;
    
public:
    HIH8121(uint8_t address);
    void begin();
    void readSensor();
    float computeHeatIndex_C(void);
    float computeHeatIndex_F(void);

    float humidity;
    float temperature_C;
    float temperature_F;
    
};

#endif